Project Description : (filter, Add, remove, clear) Task items to/from LocalStorage from UI.
                       Adding list items as JSON object in localStorage of browser & retrieving the same after browser refresh.

Tools used: Javascript, HTML, CSS styling link.

